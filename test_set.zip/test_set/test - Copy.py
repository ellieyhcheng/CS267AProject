import json
import requests
import urllib.request
# from skimage import io, color
f = open("test.csv", 'a')
# f.write('artist,patternId,previewImage,palette,templateId\n')

for i in range(8,11):

    res = requests.get("http://www.colourlovers.com/api/patterns/top", params={"format": "json", "numResults": 100, 'resultOffset': i * 100})
    patterns = res.json()

    for p in patterns:
        print(p["id"])
        urllib.request.urlretrieve(p["imageUrl"], str(p["id"]) + ".png")

        f.write(p["userName"] + ',' + str(p['id']) + ',' + p['imageUrl'] + ',')

        for c in p["colors"]:
            f.write(str(c) + " ")

        f.write('\n')

f.close()
# lab = color.rgb2lab(rgb)
# map each pixel to a the closest color in source palette
